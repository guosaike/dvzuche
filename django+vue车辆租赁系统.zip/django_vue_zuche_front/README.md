# mall-admin

该模板将帮助您开始在Vite中使用Vue 3进行开发。

## 推荐的IDE设置

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur) + [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin).

## 自定义配置

看 [快速配置参考](https://cn.vitejs.dev/config/).

## 项目设置

```sh
npm install
```

### 编译和热重新加载用于开发

```sh
npm run dev
```

### 为生产而编译和最小化

```sh
npm run build
```
